module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  const { messages } = req.body || {};

  if (!Array.isArray(messages)) {
    res.status(400).json({ error: 'Missing messages array' });
    return;
  }

  try {
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.GROQ_API_KEY}`
      },
      body: JSON.stringify({
        model: 'llama-3.3-70b-versatile',
        max_tokens: 1000,
        messages: [
          {
            role: 'system',
            content: "You are Esrael AI, a friendly and helpful everyday assistant. Keep responses clear, warm, and concise unless the user asks for more depth."
          },
          ...messages
        ]
      })
    });

    const data = await response.json();

    if (!response.ok) {
      res.status(response.status).json({ error: data.error?.message || 'Upstream error' });
      return;
    }

    // Normalize to the same shape the frontend expects: { content: [{ type: 'text', text }] }
    const reply = data.choices?.[0]?.message?.content || '';
    res.status(200).json({ content: [{ type: 'text', text: reply }] });
  } catch (err) {
    res.status(500).json({ error: 'Server error reaching Groq' });
  }
};
