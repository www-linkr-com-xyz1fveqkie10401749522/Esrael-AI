# Your AI Chat Website

This has two parts:
- `public/index.html` — the website people see (frontend)
- `server/server.js` — the server that talks to Claude and keeps your API key safe (backend)

## 1. Get an API key
Go to https://console.anthropic.com, sign up, and create an API key.

## 2. Set up the server
Open a terminal in the `server` folder and run:

```
npm install
```

Copy `.env.example` to a new file named `.env`, and paste your real API key in:

```
ANTHROPIC_API_KEY=sk-ant-xxxxxxxx
PORT=3000
```

## 3. Run it locally (to test)

```
npm start
```

Then open http://localhost:3000 in your browser — your chatbot is live.

## 4. Put it online for real (so anyone can visit it)

Easiest free/cheap options that support this Node.js + API key setup:
- **Render** (render.com) — free tier, very beginner-friendly
- **Railway** (railway.app) — simple, generous free tier
- **Fly.io** — good free tier, slightly more technical

General steps for any of them:
1. Create a free account.
2. Create a new "Web Service" and connect it to this project (upload the whole `ai-chat-app` folder, or push it to a free GitHub repo first and connect that).
3. In the site's settings, add an **environment variable**: `ANTHROPIC_API_KEY` = your key. (Never put the key directly in your code.)
4. Set the start command to `npm start` (inside the `server` folder).
5. Deploy — you'll get a public URL like `https://your-app.onrender.com`.

That's it — that URL is your live AI website you can share with anyone.
